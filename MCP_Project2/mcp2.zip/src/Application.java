import java.util.Random;

public class Application implements Runnable {

	ConcurrentLinkedListInterface cll;
	int val;
	int testFlavor;

	public Application(ConcurrentLinkedListInterface cll, int val, int testFlavor) {
		this.cll = cll;
		this.val = val;
		this.testFlavor = testFlavor;
	}

	public void run() {
		Random random = new Random();
		int key = 10;
		int searchKey = 1;

		for (int i = 0; i < 1000; i++) {
			int number = random.nextInt(1001);

			if (testFlavor == 1) {
				if (number >= 0 && number < 900) {
					cll.search(searchKey);
					searchKey += 1;
				} else if (number >= 900 && number < 990) {
					cll.insert(key);
					key += 10;
				} else {
					cll.delete(key);
					key += 20;
				}
			}
			else if(testFlavor == 2) {
				if (number  >= 0 && number < 700) {
					cll.search(searchKey);
					searchKey += 2;
				} else if (number >= 700 && number < 900) {
					cll.insert(key);
					key += 10;
				} else {
					cll.delete(key);
					key += 20;
				}
			}
			
			else if(testFlavor == 3) {
				if(number >= 0 && number < 500) {
					System.out.println("Insert: " + key);
					cll.insert(key);
					key += 10;
				} else {
					System.out.println("Delete: " + key);
					cll.delete(key);
					key += 10;
				}
			}
		}
	}
}
