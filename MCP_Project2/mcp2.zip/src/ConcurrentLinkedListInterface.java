
public interface ConcurrentLinkedListInterface {

    boolean search(int key);

    boolean insert(int key);

    boolean delete(int key);
    
    void printList();

}